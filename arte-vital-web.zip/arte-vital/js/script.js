(function () {
  "use strict";

  var track = document.getElementById("track");
  var slides = Array.prototype.slice.call(track.children);
  var viewport = document.getElementById("viewport");
  var dotsWrap = document.getElementById("dots");
  var prevBtn = document.getElementById("prevBtn");
  var nextBtn = document.getElementById("nextBtn");
  var total = slides.length;
  var index = 0;
  var autoplayMs = 6000;
  var timer = null;

  // Construir los puntos de navegación
  slides.forEach(function (_, i) {
    var dot = document.createElement("button");
    dot.type = "button";
    dot.setAttribute("aria-label", "Ir a la obra " + (i + 1));
    if (i === 0) dot.setAttribute("aria-current", "true");
    dot.addEventListener("click", function () {
      goTo(i);
      restartAutoplay();
    });
    dotsWrap.appendChild(dot);
  });
  var dots = Array.prototype.slice.call(dotsWrap.children);

  function update() {
    track.style.transform = "translateX(-" + index * 100 + "%)";
    dots.forEach(function (d, i) {
      if (i === index) {
        d.setAttribute("aria-current", "true");
      } else {
        d.removeAttribute("aria-current");
      }
    });
  }

  function goTo(i) {
    index = (i + total) % total;
    update();
  }

  function next() { goTo(index + 1); }
  function prev() { goTo(index - 1); }

  nextBtn.addEventListener("click", function () { next(); restartAutoplay(); });
  prevBtn.addEventListener("click", function () { prev(); restartAutoplay(); });

  // Teclado
  viewport.setAttribute("tabindex", "0");
  viewport.addEventListener("keydown", function (e) {
    if (e.key === "ArrowRight") { next(); restartAutoplay(); }
    if (e.key === "ArrowLeft") { prev(); restartAutoplay(); }
  });

  // Autoplay, pausado al interactuar o al pasar el mouse
  function startAutoplay() {
    stopAutoplay();
    timer = setInterval(next, autoplayMs);
  }
  function stopAutoplay() {
    if (timer) clearInterval(timer);
  }
  function restartAutoplay() {
    startAutoplay();
  }
  var carrusel = document.getElementById("carrusel");
  carrusel.addEventListener("mouseenter", stopAutoplay);
  carrusel.addEventListener("mouseleave", startAutoplay);

  // Swipe táctil / arrastre con mouse
  var startX = 0;
  var deltaX = 0;
  var dragging = false;

  function onDragStart(x) {
    dragging = true;
    startX = x;
    deltaX = 0;
    stopAutoplay();
    track.style.transition = "none";
  }
  function onDragMove(x) {
    if (!dragging) return;
    deltaX = x - startX;
    var pct = (deltaX / viewport.clientWidth) * 100;
    track.style.transform = "translateX(calc(-" + index * 100 + "% + " + pct + "%))";
  }
  function onDragEnd() {
    if (!dragging) return;
    dragging = false;
    track.style.transition = "";
    if (Math.abs(deltaX) > viewport.clientWidth * 0.18) {
      if (deltaX < 0) next(); else prev();
    } else {
      update();
    }
    startAutoplay();
  }

  track.addEventListener("touchstart", function (e) { onDragStart(e.touches[0].clientX); }, { passive: true });
  track.addEventListener("touchmove", function (e) { onDragMove(e.touches[0].clientX); }, { passive: true });
  track.addEventListener("touchend", onDragEnd);

  track.addEventListener("mousedown", function (e) { e.preventDefault(); onDragStart(e.clientX); });
  window.addEventListener("mousemove", function (e) { onDragMove(e.clientX); });
  window.addEventListener("mouseup", onDragEnd);

  window.addEventListener("resize", update);

  update();
  startAutoplay();

  // Año en el footer
  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();
})();
